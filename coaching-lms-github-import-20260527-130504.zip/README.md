# Udaan Coaching LMS

Static coaching website with LMS pages, mock tests, course pages, and a nested FastAPI backend prototype.

## Project layout

- `index.html` and the other root `.html` files are the public website pages.
- `assets/` contains shared CSS, JavaScript, and images.
- `launch-server.js` starts a small local preview server for the static site.
- `coaching-lms/` contains the FastAPI backend prototype and its own setup notes.

## Run the static site

```bash
npm start
```

Then open the local URL printed by the server.

## Run the backend prototype

```bash
cd coaching-lms
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
cd backend
uvicorn main:app --reload
```

The API docs will be available at `http://localhost:8000/docs`.

## Notes for Jules

This repository is ready for direct GitHub import. Start with the root files for the static website, and use the nested `coaching-lms/` folder when working on the FastAPI backend.
